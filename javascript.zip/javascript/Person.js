class Person {
    constructor(name, age, country) {
        this.name = name;
        this.age = age;
        this.country = country;
    }

    displayDetails() {
        console.log(`Name: ${this.name}`);
        console.log(`Age: ${this.age}`);
        console.log(`Country: ${this.country}`);
    }
}

// Create instances of the Person class
const person1 = new Person('Pochie Reyes', 25, 'Australia');
const person2 = new Person('Richard Umali', 40, 'Netherlands');
const person3 = new Person('Pia Tuazon', 33, 'Singapore');

// Display details of person1
console.log('Person-1 Details:');
person1.displayDetails();

// Display details of person2
console.log('\nPerson-2 Details:');
person2.displayDetails();

console.log('\nPerson-3 Details:');
person3.displayDetails();