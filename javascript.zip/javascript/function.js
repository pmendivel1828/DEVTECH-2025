let product = function(x, y) {
    return x * y;
};

let result = product(5, 10);

console.log(result);